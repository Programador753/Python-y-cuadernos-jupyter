numero_1 = float(input("Escriba número :"))
numero_2 = float(input("Escriba numero :"))

if numero_1 > numero_2:
    print("Menor:",numero_2,"Mayor:",numero_1,)
elif numero_1 < numero_2:
    print("Menor:",numero_1,"Mayor:",numero_2,)
else:
    print("Los dos números son iguales.")