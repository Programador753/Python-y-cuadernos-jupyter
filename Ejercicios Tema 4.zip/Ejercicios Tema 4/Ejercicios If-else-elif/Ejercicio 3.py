par = int(input("Escriba un número par: "))
impar = int(input("Escriba un número impar: "))

if par % 2 == 1:
    print("No ha escrito un número par.")
    
if impar % 2 == 0:
    print("No ha escrito un número impar.")
    
else:
    exit