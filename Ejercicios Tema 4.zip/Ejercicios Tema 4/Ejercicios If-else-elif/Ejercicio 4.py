par = int(input("Escriba un número par: "))
if par % 2 == 1:
    print("No ha escrito un número par.")

impar = int(input("Escriba un número impar: "))
if impar % 2 == 0:
    print("No ha escrito un número impar.")