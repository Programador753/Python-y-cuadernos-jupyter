par = int(input("Introduzca un numero par:") )
impar = int(input("Introduzca un numero impar:") )

if par % 2 == 1 or impar % 2 == 0:
  print("Uno o mas valores no son correctos vuelva a intentarlo")
else:
  exit