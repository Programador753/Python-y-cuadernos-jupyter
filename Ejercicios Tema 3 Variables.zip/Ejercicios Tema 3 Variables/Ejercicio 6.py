#Este programa pide la temperatura en grados Fahrenheit y los pasa a Celsius.

#Declaro las variables Fahrenheit y Celsius
Fahrenheit = float(input("Introduzaca temperatura en grados Fahrenheit:") )
Celsius = float((Fahrenheit-32)/1.8)
#Imprimo en pantalla la temperatura en grados Celsius
print("Su temperatura es de:",Celsius,"grados celsius")