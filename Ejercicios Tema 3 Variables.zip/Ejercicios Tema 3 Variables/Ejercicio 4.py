#Este programa te pide una distancia en pulgadas y te lo da en centimetros

#Declaro las variables Pulgadas y Total
Pulgadas = float(input("Introduzca distancia en Pulgadas:") )
Total = float(Pulgadas*2.54)
#Imprimo en pantalla la distancia en centimetros
print("Su distancia es de:",Total,"cm")