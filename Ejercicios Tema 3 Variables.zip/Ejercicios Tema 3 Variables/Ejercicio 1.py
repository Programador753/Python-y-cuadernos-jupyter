#Este programa solicita dos numeros al usuario y luego los muestra en una frase

numero1 = int(input("Introducir el primer numero: ") )
numero2 = int(input("Introducir el segundo numero: ") )

print("Los numeros son:",numero1," y ",numero2,)
Media = ((numero1+numero2)/2)
print('La media de estos dos numeros es:',Media,)
